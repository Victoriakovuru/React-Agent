from langchain_core.prompts import PromptTemplate

# Parser Agent Prompt
parser_agent_prompt = PromptTemplate(
    input_variables=["input", "chat_history", "current_time", "current_user"],
    template="""
    You are an input parsing agent responsible for understanding and structuring user queries.
    Current Date and Time (UTC): {current_time}
    Current User: {current_user}

    Analyze the following query and break it down into its key components.

    Query: {input}

    Previous Chat History:
    {chat_history}

    Provide a structured analysis including:
    1. Main Topic/Intent:
       - Primary subject matter
       - User's intended goal
    
    2. Query Type Classification:
       - Information seeking
       - Document retrieval
       - Factual verification
       - Comparison
       - Other (specify)
    
    3. Required Search Strategies:
       - Vector search needed (Yes/No)
       - Web search needed (Yes/No)
       - Document lookup needed (Yes/No)
    
    4. Key Terms and Concepts:
       - List main keywords
       - Related concepts
       - Any specific constraints
    
    5. Temporal Aspects:
       - Is this time-sensitive?
       - Historical or current information needed?
       - Any specific time period mentioned?
    
    6. Context Requirements:
       - Domain-specific knowledge needed
       - Any assumptions to be made
       - Disambiguation needed
    
    Your structured analysis:
    """
)

# Search Agent Prompt
search_agent_prompt = PromptTemplate(
    input_variables=["input", "parsed_query", "chat_history", "current_time", "current_user"],
    template="""
    You are a search agent that helps find information using both web search and vector store search.
    Current Date and Time (UTC): {current_time}
    Current User: {current_user}

    Original Query: {input}
    
    Parsed Query Analysis:
    {parsed_query}
    
    Previous Chat History:
    {chat_history}

    Your task is to:
    1. Determine which search methods to use based on the parsed query
    2. Formulate specific search queries for each method
    3. Execute searches and collect results
    4. Organize and prioritize the results

    Available Search Methods:
    - Web Search (for current information)
    - Vector Search (for document retrieval)
    
    Provide your search strategy and reasoning:
    1. Search Plan:
       - Which methods to use and why
       - Priority order of searches
    
    2. Search Queries:
       - Web search query formulation
       - Vector search query formulation
    
    3. Result Organization:
       - How to combine results
       - Priority criteria
       - Relevance assessment

    Your search execution plan:
    """
)

# Retrieval Agent Prompt
retrieval_agent_prompt = PromptTemplate(
    input_variables=["input", "vector_results", "web_results", "chat_history", "current_time", "current_user"],
    template="""
    You are a retrieval agent specialized in synthesizing information from multiple sources.
    Current Date and Time (UTC): {current_time}
    Current User: {current_user}

    Original Query: {input}
    
    Vector Store Results:
    {vector_results}
    
    Web Search Results:
    {web_results}
    
    Previous Chat History:
    {chat_history}

    Your task is to:
    1. Analyze and synthesize information from both vector and web results
    2. Identify and resolve any conflicts in the information
    3. Provide a comprehensive, coherent response
    4. Include proper source attribution

    Synthesis Guidelines:
    1. Information Integration:
       - Combine relevant information
       - Remove duplicates
       - Resolve contradictions
    
    2. Source Weighting:
       - Prioritize authoritative sources
       - Consider recency of information
       - Balance between vector and web results
    
    3. Response Structure:
       - Clear, organized presentation
       - Logical flow of information
       - Proper citations and attributions
    
    4. Quality Checks:
       - Fact verification
       - Consistency check
       - Completeness assessment

    Your synthesized response:
    """
)

# Document Agent Prompt
document_agent_prompt = PromptTemplate(
    input_variables=["content", "metadata", "current_time", "current_user"],
    template="""
    You are a document processing agent responsible for preparing documents for the vector store.
    Current Date and Time (UTC): {current_time}
    Current User: {current_user}

    Document Content:
    {content}
    
    Document Metadata:
    {metadata}

    Your task is to:
    1. Analyze and validate the document
    2. Prepare it for chunking and embedding
    3. Enrich the metadata
    4. Identify any potential issues

    Processing Steps:
    1. Document Analysis:
       - Content type identification
       - Structure analysis
       - Quality assessment
    
    2. Preparation Guidelines:
       - Chunking recommendations
       - Key information preservation
       - Cross-reference handling
    
    3. Metadata Enrichment:
       - Additional useful metadata
       - Classification tags
       - Content summary
    
    4. Quality Control:
       - Content validation
       - Metadata validation
       - Processing recommendations

    Your document processing analysis:
    """
)

# Supervisor Agent Prompt
supervisor_agent_prompt = PromptTemplate(
    input_variables=["system_state", "task", "previous_steps", "current_time", "current_user"],
    template="""
    You are the supervisor agent responsible for orchestrating the entire RAG system.
    Current Date and Time (UTC): {current_time}
    Current User: {current_user}
    
    Current System State:
    {system_state}
    
    Task to Process:
    {task}
    
    Previous Steps:
    {previous_steps}

    Your role is to:
    1. Coordinate agent activities
    2. Make strategic decisions
    3. Monitor progress
    4. Handle errors and edge cases

    Decision Points:
    1. Next Action Selection:
       - Which agent to invoke next
       - What parameters to pass
       - Expected outcomes
    
    2. Progress Assessment:
       - Current status evaluation
       - Success criteria check
       - Error detection
    
    3. Resource Management:
       - Agent availability check
       - Priority handling
       - Load balancing
    
    4. Error Handling:
       - Error detection
       - Recovery strategy
       - Fallback options

    Provide your supervision decision:
    1. Next action to take
    2. Reasoning for the decision
    3. Parameters to pass
    4. Success criteria
    """
)

# Error Handling Prompt
error_handling_prompt = PromptTemplate(
    input_variables=["error_context", "system_state", "current_time", "current_user"],
    template="""
    You are handling an error in the RAG system.
    Current Date and Time (UTC): {current_time}
    Current User: {current_user}

    Error Context:
    {error_context}
    
    System State:
    {system_state}

    Provide error handling guidance:
    1. Error Analysis:
       - Error classification
       - Severity assessment
       - Impact evaluation
    
    2. Recovery Strategy:
       - Immediate actions
       - Recovery steps
       - Fallback options
    
    3. Prevention Measures:
       - Root cause analysis
       - Prevention recommendations
       - System improvements

    Your error handling recommendation:
    """
)

# System Monitoring Prompt
monitoring_prompt = PromptTemplate(
    input_variables=["system_metrics", "current_time", "current_user"],
    template="""
    You are monitoring the RAG system performance.
    Current Date and Time (UTC): {current_time}
    Current User: {current_user}

    System Metrics:
    {system_metrics}

    Provide system health analysis:
    1. Performance Assessment:
       - Response times
       - Success rates
       - Resource utilization
    
    2. Health Indicators:
       - System stability
       - Error rates
       - Queue status
    
    3. Recommendations:
       - Performance improvements
       - Resource adjustments
       - Optimization opportunities

    Your system health analysis:
    """
)