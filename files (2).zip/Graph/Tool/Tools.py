# Update the VectorStore Tool definition
VectorStore = Tool(
    name="vector_store",
    description="Add documents to the vector store",
    func=vector_store_tool.add_document,
    args_schema=DocumentRequest  # Add the schema
)