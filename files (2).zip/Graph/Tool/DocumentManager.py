from typing import List, Dict, Union, Any
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from chromadb import Chroma
import os
import datetime

class DocumentManager:
    def __init__(self, collection_name: str = "default_collection"):
        self.collection_name = collection_name
        self.embeddings = HuggingFaceEmbeddings()
        self.db = Chroma(
            collection_name=collection_name,
            embedding_function=self.embeddings
        )
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )
    
    def process_document(self, 
                        content: str, 
                        metadata: Dict[str, Any]) -> List[Document]:
        """Split document into chunks and prepare for insertion"""
        # Add processing metadata
        metadata.update({
            "ingestion_date": datetime.datetime.utcnow().isoformat(),
            "processed_by": os.getenv("USER", "unknown")
        })
        
        # Split text into chunks
        texts = self.text_splitter.split_text(content)
        
        # Create Document objects
        documents = [
            Document(
                page_content=chunk,
                metadata={
                    **metadata,
                    "chunk_id": f"chunk_{i}",
                }
            )
            for i, chunk in enumerate(texts)
        ]
        
        return documents
    
    def add_documents(self, 
                     documents: List[Document]) -> Dict[str, Any]:
        """Add documents to ChromaDB"""
        try:
            # Convert documents to ChromaDB format
            texts = [doc.page_content for doc in documents]
            metadatas = [doc.metadata for doc in documents]
            ids = [f"doc_{i}_{datetime.datetime.utcnow().timestamp()}" 
                  for i in range(len(documents))]
            
            # Add to ChromaDB
            self.db.add_documents(
                documents=texts,
                metadatas=metadatas,
                ids=ids
            )
            
            return {
                "status": "success",
                "message": f"Successfully added {len(documents)} documents",
                "document_ids": ids
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Error adding documents: {str(e)}",
                "document_ids": []
            }