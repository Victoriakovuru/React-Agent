from Config.llm import llm
from Graph.Tool.DocumentManager import DocumentManager
from langgraph.prebuilt.chat_agent_executor import create_react_agent
from Graph.Prompt.prompts import document_insertion_prompt
from typing import Dict, Any
import datetime

class DocumentInsertionAgent:
    def __init__(self):
        self.doc_manager = DocumentManager()
        self.agent = create_react_agent(
            llm,
            tools=[],
            name="document_insertion",
            prompt=document_insertion_prompt
        )
    
    def insert_document(self, 
                       content: str, 
                       metadata: Dict[str, Any] = None) -> Dict[str, Any]:
        """Process and insert a document into the vector database"""
        if metadata is None:
            metadata = {}
        
        # Get current time and user
        current_time = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        current_user = os.getenv("USER", "unknown")
        
        # Process document with the agent
        agent_response = self.agent.invoke({
            "content": content,
            "metadata": metadata,
            "current_time": current_time,
            "current_user": current_user
        })
        
        # Process document with DocumentManager
        documents = self.doc_manager.process_document(content, metadata)
        
        # Insert into ChromaDB
        insertion_result = self.doc_manager.add_documents(documents)
        
        return {
            "agent_response": agent_response,
            "insertion_result": insertion_result
        }