from langchain.memory import ConversationBufferMemory
from langchain.memory import FileChatMessageHistory
from typing import Dict, Any
import json
import os

class ShortTermMemory:
    def __init__(self):
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True
        )
    
    def add_to_memory(self, input_str: str, output_str: str):
        self.memory.save_context(
            {"input": input_str},
            {"output": output_str}
        )
    
    def get_memory(self) -> Dict[str, Any]:
        return self.memory.load_memory_variables({})

class LongTermMemory:
    def __init__(self, file_path: str = "long_term_memory.json"):
        self.file_path = file_path
    
    def save(self, data: Dict[str, Any]):
        with open(self.file_path, 'w') as f:
            json.dump(data, f)
    
    def load(self) -> Dict[str, Any]:
        if not os.path.exists(self.file_path):
            return {}
        with open(self.file_path, 'r') as f:
            return json.load(f)

# Initialize memory stores
short_term_memory_store = ShortTermMemory()

def load_and_save_long_term(data: Dict[str, Any] = None) -> Dict[str, Any]:
    long_term_memory = LongTermMemory()
    if data:
        long_term_memory.save(data)
    return long_term_memory.load()